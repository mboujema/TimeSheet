import React from 'react';

export default function Timesheet({prenomm,nomm}) {
   
    
    return (
        <div className = 'Timesheettt'>

            <h3>Bonjour {nomm} {prenomm} !</h3>

        </div>
    )

}